import React from "react";

export const Services = () => {
  return (
    <div>
      <h1>Services</h1>
    </div>
  );
};
